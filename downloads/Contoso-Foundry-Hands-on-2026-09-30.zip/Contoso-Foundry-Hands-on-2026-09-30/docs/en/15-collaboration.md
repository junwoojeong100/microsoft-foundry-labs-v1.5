> **What you will build:** Distinguish a drafter revising after review from transferring control to a specialist.

<div class="lab-brief" markdown="1">

**Format:** Advanced elective · reuse L13's environment and run two patterns one at a time.

**Start here:** Read both plans below and predict whether the task needs revision or a change of owner.

**What to check:** Find group chat's three contributions and handoff's actual tool call and specialist answer. Distinguish a termination message from the business answer.

</div>

## Objectives

**“Discuss together” and “change the responsible agent” are different.** Group chat returns a review to the same drafter; handoff lets a specialist take over. Neither replaces human purchasing approval.

## Concepts and lab map

**What you will try:** Message and control transfer with `GroupChatBuilder` and `HandoffBuilder`.

**What is it, and why does it matter?** Group chat supports iterative team review; handoff changes ownership. Saying “I delegated” does not prove control transferred.

**How do you use it?** Run both patterns against the same policy and question. Inspect intermediate answers and actual delegation calls without increasing iteration or cost limits.

**Where do you run it?** Run [multi_agent.py](../../samples/multi_agent.py) in `.venv-advanced`. Only the model is in Microsoft Azure; no Hosted or remote A2A server is created.

## Prerequisites

Reuse [L13's setup](#l15): `.venv-advanced`, `.env`, **your own** `results/azure-environment.json`, and the chat **100,000 TPM / 60 RPM** check. L13's paid patterns are not prerequisites. Keep the English profile selected.

<details class="environment-option" markdown="1">
<summary>Only when using Windows PowerShell on your PC</summary>

Use `.venv-advanced\Scripts\python.exe`. In Codespaces, use the Bash commands below unchanged.

</details>

### Choose your starting path

| Current state | Steps to follow | What to retain |
| --- | --- | --- |
| No Microsoft Azure approval | Read both plans in step 1 | Explain differences and call limits; actual execution remains not performed |
| Model, receipt, and cost approval ready | Plan → group chat → inspect → handoff → compare | Two original files and a revision/delegation comparison |

No additional resources need deployment. Both patterns together use **at most seven model calls**. Preserve **180 seconds per run, 2,048 output tokens per response, and zero retries**. Start the next pattern **at least one minute** after the previous start.

## Steps

### 1. Predict both flows before execution

```bash
.venv-advanced/bin/python samples/multi_agent.py --mode group-chat
.venv-advanced/bin/python samples/multi_agent.py --mode handoff
```

<div class="command-explanation" markdown="1">

**Command walkthrough**

| Order and command | Details and options | Result, cost, or change |
| --- | --- | --- |
| 1. `--mode group-chat` | Read the drafter → reviewer → revised draft plan. | No SDK initialization, Microsoft Azure call, or execution evidence. Plans at most three calls. |
| 2. `--mode handoff` | Read the coordinator → policy or budget specialist plan. | No actual delegation. Plans at most four calls. |

</div>

Predict group chat for “review and improve advice on a KRW 2,900,000 purchase,” and handoff for “choose the policy or budget specialist.” **A prediction is not a result.** Inspect actual transfer in the next steps.

### 2. Group chat: read the final revision

```bash
.venv-advanced/bin/python samples/multi_agent.py --mode group-chat --live
```

<div class="command-explanation" markdown="1">

**Command walkthrough**

| Order and command | Details and options | Result, cost, or change |
| --- | --- | --- |
| 1. `--mode group-chat --live` | Run three contributions, returning the review to the drafter. Code chooses speakers round-robin; no model moderator is added. | At most three actual model calls. Inspect output and the original `Evidence:` file. |

</div>

Open the `Evidence:` file in an editor and find `paths.group-chat.stages`. Read first draft → review → final draft side by side. Use `payload.input` from `model_call_completed` events and `input_authors` to verify that the review was passed into the next request.

| What to inspect | Decision |
| --- | --- |
| Each of the three stages' `role` | Are they drafter, reviewer, drafter in order? |
| First and last `answer` | Were identified omissions addressed? Record unchanged output honestly |
| `final_messages`, `workflow_state` | Did execution terminate? An orchestrator's termination notice is not purchasing advice |

### 3. Handoff: find actual control transfer

```bash
.venv-advanced/bin/python samples/multi_agent.py --mode handoff --live
```

<div class="command-explanation" markdown="1">

**Command walkthrough**

| Order and command | Details and options | Result, cost, or change |
| --- | --- | --- |
| 1. `--mode handoff --live` | Transfer control to an allowed policy or budget specialist. The specialist answers and terminates without delegating again. | At most four model calls. Missing tool/specialist evidence fails. No order or human approval. |

</div>

Under `paths.handoff.stages`, find the coordinator's `handoff_calls` followed by the specialist's response. Check that a `handoff_to_…` tool was recorded and the chosen specialist actually answered. A natural-language delegation claim without a tool call does not pass.

The sample sets `require_per_service_call_history_persistence=True` to retain conversation history across control changes. Do not remove it and hide the resulting error behind retries.

### 4. Change one condition and compare

<div class="practice-block" markdown="1">

**Try it:** Record `role order / input transfer / revised sentence / delegation tool / termination / total_tokens / elapsed_seconds` from both files. Missing usage (`null`) is not zero.

**Change one thing:** If additional calls are approved, add only `--case boundary` to one chosen pattern. Compare exactly KRW 2,000,000 with KRW 2,000,001, leaving the model, policy, and role instructions unchanged. If you only read plans, mark the actual comparison not performed.

**Explain the result:** Choose “group chat because revision is needed” or “handoff because ownership must change” for your task, citing actual inputs and responses. Extra calls alone do not prove better quality.

</div>

### 5. Identify what this exercise does not implement

Handoff between local roles is **not a remote Agent2Agent (A2A) connection**. Human-in-the-loop approval, incoming A2A endpoints, and organizational delegation are also outside this implementation. Start with separate authentication, protocol, and user-permission design before connecting external agents.

Compare the Builder responsibilities using the official [group-chat](https://learn.microsoft.com/agent-framework/workflows/orchestrations/group-chat?pivots=programming-language-python) and [handoff](https://learn.microsoft.com/agent-framework/workflows/orchestrations/handoff?pivots=programming-language-python) documentation.

<details class="implementation-detail" markdown="1">
<summary>Implementation reference: group-chat termination and handoff configuration — read only</summary>

#### Portal model deployment and Group chat/Handoff code

L14 has no Group chat/Handoff editor in the Microsoft Foundry portal. The portal supplies the model deployment; Python Agent Framework code selects participants, routes messages, and defines termination.

```python
from agent_framework.orchestrations import GroupChatBuilder, HandoffBuilder

def select_speaker(state):
    names = list(state.participants)
    return names[state.current_round % len(names)]

group_workflow = GroupChatBuilder(
    participants=[drafter, reviewer],
    selection_func=select_speaker,
    max_rounds=3,
    termination_condition=lambda messages: sum(message.role == "assistant" for message in messages) >= 3,
    intermediate_output_from=[drafter, reviewer],
).build()

handoff_workflow = (
    HandoffBuilder(
        participants=[coordinator, policy_agent, budget_agent],
        termination_condition=lambda messages: any(
            message.role == "assistant"
            and message.author_name in {"policy", "budget"}
            and message.text.strip()
            for message in messages
        ),
    )
    .with_start_agent(coordinator)
    .add_handoff(coordinator, [policy_agent, budget_agent])
    .build()
)
```

| Code setting | Actual result to inspect in Evidence |
| --- | --- |
| `participants` | Agent author for each stage |
| `selection_func`, `max_rounds` | Who spoke in group chat and where it stopped |
| `with_start_agent`, `add_handoff` | Whether a real control transfer appears in `handoff_calls` |
| Portal model deployment | Approved Microsoft Foundry model called by each participant |

Participants are SDK agents from `build_role()`. Group chat stops after three assistant turns; handoff stops after a specialist answer. `multi_agent.py` executes only the chosen workflow, without storing this graph in the portal.

</details>

## Success criteria

- Within the patterns you ran, you identified group chat's three contributions and final revision.
- You identified handoff's actual delegation call, specialist answer, and terminal state.
- You did not report review/delegation as human approval or remote A2A success.

## Troubleshooting

| Symptom | Inspect first | Next action |
| --- | --- | --- |
| SDK import fails | L13's Python environment and `pip check` | Return to the dedicated environment instead of mixing core SDKs |
| Group chat ends with only a termination notice | Whether `final_messages` was mistaken for `stages` | Read `answer` from the last drafter stage |
| No delegation tool or specialist response | `handoff_calls`, actual inputs, termination reason | Preserve the failure; do not repeat until a preferred result appears |
| 429, truncated response, or timeout | L02 throughput, request times, and bounds | Stop new calls, inspect the original error, and rerun only with approval |

## Cleanup

These executions call the owned model without creating Hosted deployments or recurring schedules. Keep originals under `results/`; after all selected labs, go to [L19 shared wrap-up](#l12).

<div class="lab-handoff" markdown="1">

**Keep:** First draft/review/revision and actual handoff tool/specialist response/termination. Keep the two patterns' `Evidence:` files separate.

**Continue:** If you select [L15 Memory](#l16), return to **the core SDK environment**. Otherwise, go to [L19](#l12).

</div>
