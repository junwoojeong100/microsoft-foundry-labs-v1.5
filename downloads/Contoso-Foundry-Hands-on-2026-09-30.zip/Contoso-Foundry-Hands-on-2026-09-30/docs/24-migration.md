> **완성할 결과:** 기존 자원을 유지하면서 새 Foundry로 이동할 항목과 검증 순서를 구분한 마이그레이션 표.

## 목표

**브랜드명 변경, 포털 전환, 리소스 업그레이드, SDK/API 마이그레이션은 서로 다른 작업**입니다.

## 개념과 실습 지도

**경험할 기능:** Classic/신규 Foundry의 리소스·API·상태·운영 차이를 분류하고 이전 계획을 작성합니다.

**무엇이며 왜 중요한가요?** 포털 이름이 바뀌어도 기존 endpoint가 자동으로 새 API가 되는 것은 아닙니다. Threads/Runs 기반 코드를 Conversations/Responses로 옮길 때는 호출 모양뿐 아니라 도구 실행 루프·저장 상태·권한·재시도도 다시 확인해야 합니다. 화면에 agent가 보이는 것만으로 사용자 대화나 삭제·보존 정책까지 이전됐다고 결론내릴 수 없습니다.

**어떻게 사용하나요?** 기존 시스템을 변경하지 않고 정의·사용자 상태·운영 상태를 목록화합니다. 새 비운영 환경에 작은 합성 경로를 구현하고 L03/L05/L06/L08/L10의 같은 검사를 적용합니다. 품질·권한·복구 조건을 통과한 뒤에만 제한된 사용자부터 전환합니다.

**어디서 실행하나요?** 이 장의 기본 결과는 마이그레이션 표이며 자동 변경 CLI는 없습니다. [현재 SDK 의존성](../requirements.txt), [Responses/도구 루프 예제](../samples/workshop.py), [배포 설정](../azure.yaml)을 기존 시스템과 비교하세요. 보존·삭제는 최종 담당자의 별도 승인입니다.

## 준비

기존 시스템이 있으면 승인된 범위에서 읽기 전용으로 목록화합니다. 없으면 아래 **가상 Contoso Classic 사례**로 계획을 작성합니다. 실습을 위해 Classic 자원을 새로 만들 필요가 없습니다. 이 장은 기존 자원을 자동 업그레이드하거나 데이터를 옮기지 않습니다.

## 실행

### 1. 현재 사용 중인 것을 찾기

| 과거/기존 | 새 경로 | 주의 |
| --- | --- | --- |
| Azure AI Studio / Azure AI Foundry | Microsoft Foundry | 이름 변경만으로 API가 바뀌지 않음 |
| hub 기반 프로젝트 | Foundry resource 아래 project | 일부 Classic 경험은 별도 유지 |
| Assistants / Threads / Runs | Agent Versions / Conversations / Responses | 호출·상태·tool loop 변경 |
| `azure-ai-projects` 1.x | 2.x project client | import만 바꾸는 작업이 아님 |
| 여러 추론 endpoint | 프로젝트/OpenAI-compatible surface | 공급자·API별 지원 확인 |
| Azure AI User 등 역할명 | Foundry User 등 | 역할 ID·scope·실제 permissions 확인 |

standalone Azure OpenAI 자원과 Classic hub 기반 프로젝트는 새 포털의 모든 경로에 바로 들어가는 것이 아닙니다. 공식 upgrade/migration 절차를 따릅니다.

Azure Government 등 sovereign cloud는 endpoint·인증 audience·서비스/모델 지원 범위가 별도입니다. public cloud용 이 가이드의 환경 파일을 주소만 일부 바꿔 재사용하지 말고 해당 클라우드의 공식 지원 문서를 기준으로 이전 계획을 세웁니다.

### 2. 세 상태를 분리해서 이전 계획 만들기

**정의:** instructions, model, tools, connections.  
**사용자 상태:** conversations, memory, 파일, vector stores.  
**운영 상태:** endpoint, identity, 권한, monitoring, 평가 결과, 게시 채널.

API migration 도구가 정의를 옮겼다고 사용자 대화나 업무 승인 상태까지 모두 이전됐다고 가정하지 않습니다.

**완성 예 — 가상의 기존 구매 도우미이며 실제 이관 결과가 아닙니다.**

| 구분·기존 항목 | 새 경로의 결정 | 확인할 것 / 실패하면 |
| --- | --- | --- |
| 정의: instructions·함수 schema | 현재 v2와 L06 계약에 각각 대응. 이름만 치환하지 않음 | 수량 1~10·미주문 경계 비교. 다르면 함수/계약 수정 후 재검토 |
| 지식: 정책 파일 3개·vector store | 승인 후 새 환경에 원문을 올리고 새 file/store ID 기록 | L05의 실제 citation이 새 파일·같은 절을 가리키는지. 실패 시 파일→store→agent 연결 확인 |
| 사용자 상태: Thread/Run | 새 conversation으로 시험. 기존 ID를 그대로 사용하지 않음 | 새 대화에서 필요한 맥락만 전달되는지. 사용자 이력 이관은 별도 범위/보존 계획 |
| 운영: identity·endpoint·모델 | 새 환경별 바인딩과 최소 권한을 명시 | L03 응답과 L10 trace 연결. 403/404는 권한·주소·버전부터 분리 |
| 게시·복구 | 기존 endpoint는 유지하고 테스트 사용자만 새 경로 사용 | L22 이전 설정 묶음으로 돌아갈 수 있는지. 기존 자원 삭제는 전환과 분리 |

자신의 표에는 **원본 위치·담당자·보존 결정·검증 파일/ID·미해결 항목**을 덧붙입니다. 예시 결정을 실제 환경에 적용하기 전에 현재 제품의 migration 지원 범위를 확인합니다.

### 3. 새 환경에서 회귀 확인하기

실제 이관을 승인받은 경우에만 새 비운영 환경에서 같은 합성 입력을 비교합니다. 기본 설계 과제는 아래 표에 사용할 입력과 근거 위치를 적는 것으로 진행합니다.

| 확인할 것 | 어떻게 판단하나요? | 실패하면 다음 행동 |
| --- | --- | --- |
| L03 모델 호출 | 완료된 응답, 실제 배포 이름·response ID | endpoint/token audience·모델 지원 확인 |
| L05 정책 질문 | 상한 150만 원·부가세 포함·36개월과 실제 새 citation | 원문/인덱싱/store 바인딩부터 확인 |
| L06 정상·실패 입력 | NB-14 2대는 총액 290만 원·미주문; 품절/음수 수량은 오류 | schema·dispatcher·도구 결과 전달 순서 확인 |
| L08 지침 비교 | 동일 언어·문맥·모델·질문·기준의 실제 차이 | 기존 비교와 조건이 다르면 직접 우열 주장 금지. 기존 결과 덮어쓰기·봉인 holdout 재사용 금지 |
| L10 추적 | 새 응답과 새 환경의 trace 연결 | 이전 환경 로그를 대신 붙이지 않고 연결·시각·권한 확인 |

L08의 도구 없는 비교는 위의 통합 함수·검색 시험을 대체하지 않습니다. endpoint·schema·재시도·저장/보존 정책 차이는 각각 기록하며, 실행하지 않은 검사는 빈 성공 표시 대신 미실행으로 남깁니다.

### 4. 종료 예정 기능을 먼저 제거하기

포털 Workflows의 **2026-12-01 종료 예정**을 일정에 반영하고 신규 의존성을 만들지 않습니다. 필요한 orchestration은 Microsoft Agent Framework 등 현재 지원 경로로 이전하고, checkpoint·사람 승인·실패 재개를 다시 검증합니다.

AI Search agentic retrieval은 stable `2026-04-01`와 최신 preview 간 기능·payload 차이가 있습니다. Knowledge source·client 이름·pagination·Work IQ 인증·response 처리 변경을 공식 migration 표와 대조합니다.

### 5. 단계적 전환과 복구 기준 정의하기

테스트 사용자 → 제한된 traffic → 승인된 확대 순서로 진행합니다. **후보가 citation 없이 정답만 말하거나 주문 완료를 가장한다면 확대를 보류**하는 것이 이 사례의 결정입니다. 먼저 새 경로의 실패 원본을 보존하고, 담당자가 승인된 이전 endpoint/버전·설정을 선택합니다. 상태가 호환되는지 확인한 뒤 실제 복구 호출을 별도 검증합니다.

표의 품질·권한·복구 항목 중 하나라도 미확인이면 “이관 완료”가 아니라 **전환 보류 / 필요한 다음 확인**을 적습니다. 기존 endpoint나 사용자 상태를 성급히 삭제하지 않습니다.

## 성공 기준

이전 대상, 유지할 Classic 기능, 사용자 상태의 처리, 종료 일정, 평가 결과, rollback 방법이 있습니다. “새 포털에서 보인다”만으로 마이그레이션 완료를 판정하지 않습니다.

## 막혔을 때

브랜드가 같아도 오래된 문서 URL/SDK 예제의 resource model은 다를 수 있습니다. `foundry-classic`, `azure-ai-projects 1.x`, Threads/Runs 여부를 먼저 확인합니다.

## 정리

새 경로가 실제 사용과 평가에서 통과하고 복구 기간이 끝난 후, 담당자가 기존 자원의 보존·삭제를 승인합니다.
