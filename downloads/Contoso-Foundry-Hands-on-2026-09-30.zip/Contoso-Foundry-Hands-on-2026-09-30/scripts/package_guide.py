"""Create a portable kit without virtualenvs, generated cloud results, credentials, or maintainer-only validation assets."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
from urllib.parse import unquote, urlparse
import zipfile
import zlib

from check_guide import GuideParser
from build_guide import load_portal_captures

ROOT = Path(__file__).resolve().parents[1]
RELEASE = json.loads((ROOT / "content/release.json").read_text())
NAME = RELEASE["artifact"]
# Listed in content/maintainer-only.json: kept in the repository, never shipped to learners.
MAINTAINER_ONLY = tuple(json.loads((ROOT / "content/maintainer-only.json").read_text(encoding="utf-8"))["paths"])


def is_maintainer_only(path):
    name = Path(path).as_posix()
    return any(name == listed or name.startswith(listed + "/") for listed in MAINTAINER_ONLY)


def check_package_path(path):
    parts = Path(path).parts
    if any(
        part.startswith(".venv") or part in {"__pycache__", "results", "validation", ".azure", ".git", ".foundry", "node_modules"}
        for part in parts
    ) or parts[-1] == ".env":
        raise ValueError(f"Private or generated cloud data in package: {path}")


IGNORED_NAMES = {".DS_Store", "Thumbs.db"}
ROOT_FILES = (
    ".nojekyll",
    ".env.example", ".gitignore", "requirements.txt",
    "requirements-docs.txt", "requirements-advanced.txt", "requirements-local.txt",
    "requirements-hosted.txt", "requirements-tools.txt", "requirements-live.lock.txt",
    "package.json", "package-lock.json", ".python-version", "azure.yaml", "AGENTS.md", "THIRD_PARTY_NOTICES",
    "LICENSE",
)
DIRECTORIES = ("assets", "content", "data", "docs", "samples", "scripts", "tests", "hosted", "infra",
               "downloads/replay", ".github", ".devcontainer")


def collect_files(report_dir: Path) -> list[Path]:
    files = [ROOT / name for name in ROOT_FILES]
    for edition in RELEASE["languages"].values():
        files.extend(ROOT / edition[key] for key in ("readme", "html", "markdown", "receipt_html"))
        files.append(ROOT / "content" / edition["portal_manifest"])
    for directory in {ROOT / name for name in DIRECTORIES}:
        files.extend(
            path for path in directory.rglob("*")
            if path.is_file() and "__pycache__" not in path.parts and path.suffix not in {".pyc", ".tmp"}
            and path.name not in IGNORED_NAMES and path != report_dir / "package.json"
            and not is_maintainer_only(path.relative_to(ROOT))
        )
    for path in files:
        check_package_path(path.relative_to(ROOT))
        if not path.is_file() or any(
            part.is_symlink() for part in (path, *path.parents) if part.is_relative_to(ROOT)
        ):
            raise ValueError(f"Package input must be an existing regular file: {path.relative_to(ROOT)}")
    return sorted(set(files))


def entry_info(path: Path) -> zipfile.ZipInfo:
    """Same inputs give the same entries on every machine: fixed edition date, Unix attributes, sorted names."""
    year, month, day = (int(part) for part in RELEASE["edition"].split("-"))
    info = zipfile.ZipInfo(f"{NAME}/{path.relative_to(ROOT).as_posix()}", (year, month, day, 0, 0, 0))
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (0o755 if path.stat().st_mode & 0o111 else 0o644) << 16
    return info


def write_archive(target: Path, files: list[Path]) -> None:
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.writestr(entry_info(path), path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def mismatches(target: Path, files: list[Path]) -> list[str]:
    """Compare the ZIP's members (name, size, CRC-32) with the files that would be packaged now.

    CRC-32 and size do not depend on the compressor, so the check passes on any platform.
    """
    if not target.is_file():
        return [f"missing archive: {target.name}"]
    expected = {}
    for path in files:
        data = path.read_bytes()
        expected[f"{NAME}/{path.relative_to(ROOT).as_posix()}"] = (len(data), zlib.crc32(data) & 0xFFFFFFFF)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            return ["archive integrity check failed"]
        actual = {info.filename: (info.file_size, info.CRC) for info in archive.infolist()}
    problems = [f"missing from ZIP: {name}" for name in sorted(expected.keys() - actual.keys())]
    problems += [f"not in the kit sources: {name}" for name in sorted(actual.keys() - expected.keys())]
    problems += [f"differs from the source file: {name}" for name in sorted(expected.keys() & actual.keys())
                 if expected[name] != actual[name]]
    return problems


def verify_archive(target: Path, all_captures: dict) -> tuple[list[str], set[str]]:
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive integrity check failed.")
        names = archive.namelist()
        for name in names:
            check_package_path(name)
            if is_maintainer_only(name.removeprefix(f"{NAME}/")):
                raise ValueError(f"Maintainer-only asset in package: {name}")
        essentials = [
            edition[key] for edition in RELEASE["languages"].values()
            for key in ("readme", "html", "markdown", "receipt_html")
        ]
        essentials += ["content/" + edition["portal_manifest"] for edition in RELEASE["languages"].values()]
        for essential in (*essentials, "samples/workshop.py", "data/evaluation/cases.jsonl",
                          ".devcontainer/devcontainer.json", ".devcontainer/post-create.sh"):
            if f"{NAME}/{essential}" not in names:
                raise ValueError(f"Missing package artifact: {essential}")
        local_paths = set()
        for edition in RELEASE["languages"].values():
            book = ROOT / edition["markdown"]
            for address in re.findall(r"\]\(([^)\s]+)\)", book.read_text(encoding="utf-8")):
                parsed = urlparse(address)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = (book.parent / unquote(parsed.path)).resolve()
                if not path.is_relative_to(ROOT):
                    raise ValueError(f"Portable Markdown link escapes the kit: {address}")
                local_paths.add(path.relative_to(ROOT).as_posix())
            for key in ("html", "receipt_html"):
                parser = GuideParser()
                parser.feed((ROOT / edition[key]).read_text(encoding="utf-8"))
                for address in [*parser.links, *(image["src"] for image in parser.images)]:
                    parsed = urlparse(address)
                    if parsed.scheme or parsed.netloc or not parsed.path:
                        continue
                    path = (ROOT / Path(edition[key]).parent / unquote(parsed.path)).resolve()
                    if not path.is_relative_to(ROOT):
                        raise ValueError(f"Portable guide link escapes the kit: {address}")
                    relative = path.relative_to(ROOT).as_posix()
                    if relative != RELEASE["archive"]:
                        local_paths.add(relative)
        for local_path in local_paths:
            if f"{NAME}/{local_path}" not in names:
                raise ValueError(f"Portable guide link missing from ZIP: {local_path}")
        for localized_captures in all_captures.values():
            for capture in localized_captures:
                packed = archive.read(f"{NAME}/{capture['path']}")
                if hashlib.sha256(packed).hexdigest() != capture["sha256"]:
                    raise ValueError(f"Portal screenshot differs in ZIP: {capture['path']}")
    return names, local_paths


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", type=Path, default=Path(RELEASE["documentation_validation"]))
    parser.add_argument("--check", action="store_true",
                        help="Do not write: fail when the committed ZIP differs from the current sources.")
    args = parser.parse_args()
    report_dir = (ROOT / args.report_dir).resolve()
    if not report_dir.is_relative_to(ROOT / "results") or report_dir == ROOT / "results":
        raise ValueError("Reports must be inside private results/.")
    files = collect_files(report_dir)
    target = ROOT / RELEASE["archive"]
    if args.check:
        problems = mismatches(target, files)
        if problems:
            shown = "\n  ".join(problems[:15])
            more = f"\n  ... and {len(problems) - 15} more" if len(problems) > 15 else ""
            raise SystemExit(
                f"The committed ZIP is out of date with the sources ({len(problems)} differences). "
                f"Run python scripts/package_guide.py and commit the result.\n  {shown}{more}"
            )
        print(f"The committed ZIP matches the current sources ({len(files)} files).")
        return
    captures = {language: load_portal_captures(language) for language in RELEASE["languages"]}
    all_captures = {
        language: load_portal_captures(language, include_archived=True)
        for language in RELEASE["languages"]
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + ".tmp")
    try:
        write_archive(staging, files)
        names, local_paths = verify_archive(staging, all_captures)
        os.replace(staging, target)  # the published ZIP is replaced only after every check passed
    finally:
        staging.unlink(missing_ok=True)
    print(f"Packaged {len(names)} files: {target.name} ({target.stat().st_size / 1_000_000:.2f} MB)")
    report = {
        "created_at": datetime.now(timezone.utc).isoformat(), "archive": target.name,
        "files": len(names), "bytes": target.stat().st_size,
        "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "languages": list(RELEASE["languages"]), "default_language": RELEASE["default_language"],
        "integrity": "passed", "credential_and_virtualenv_exclusion": "passed",
        "portable_local_paths_checked": len(local_paths),
        "portal_screenshots": sum(len(items) for items in captures.values()),
        "portal_screenshots_by_language": {language: len(items) for language, items in captures.items()},
        "archived_portal_screenshots": sum(len(all_captures[language]) - len(items) for language, items in captures.items()),
        "note": "This archive hash is kept outside the archive to avoid a self-referential checksum.",
    }
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "package.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
