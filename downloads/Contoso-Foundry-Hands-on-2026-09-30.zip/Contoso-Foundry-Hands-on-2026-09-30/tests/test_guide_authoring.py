from collections import defaultdict
import csv
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from check_guide import command_coverage


def explanation(rows):
    return (
        '<div class="command-explanation" markdown="1">\n\n**명령 해설**\n\n'
        "| 순서·명령 | 세부 동작과 옵션 | 결과·비용/변경 |\n"
        "| --- | --- | --- |\n"
        + "\n".join(rows)
        + "\n\n</div>\n"
    )


class GuideAuthoringTests(unittest.TestCase):
    def test_all_25_labs_have_concepts_and_per_command_explanations(self):
        chapters = json.loads((ROOT / "content/chapters.json").read_text())
        labs = [chapter for chapter in chapters if chapter["track"] != "reference"]
        self.assertEqual(len(labs), 25)
        total = {"blocks": 0, "commands": 0}
        for chapter in labs:
            text = (ROOT / chapter["file"]).read_text()
            with self.subTest(lab=chapter["id"]):
                self.assertIn("## 개념과 실습 지도", text)
                for label in ("경험할 기능", "무엇이며 왜 중요한가요?", "어떻게 사용하나요?", "어디서 실행하나요?"):
                    self.assertIn("**" + label, text)
                coverage = command_coverage(text, chapter["file"])
                for key in total:
                    total[key] += coverage[key]
                for source in re.findall(r"\b(?:samples|scripts)/[\w.-]+\.py\b", text):
                    self.assertTrue((ROOT / source).is_file(), source)
        edition = json.loads((ROOT / "content/release.json").read_text())["languages"]["ko"]
        self.assertEqual(total, {"blocks": edition["shell_blocks"], "commands": edition["commands"]})

    def test_search_walkthrough_changes_mode_not_question(self):
        for directory in ("docs", "docs/en"):
            text = (ROOT / directory / "13-iq.md").read_text()
            commands = [
                shlex.split(line) for line in text.splitlines()
                if line.startswith("python samples/search_lab.py query ")
            ]
            with self.subTest(directory=directory):
                self.assertEqual(len(commands), 3)
                self.assertEqual({c[c.index("--mode") + 1] for c in commands}, {"keyword", "hybrid", "iq"})
                self.assertEqual(len({c[c.index("--query") + 1] for c in commands}), 1)
                self.assertTrue(all("--live" in command for command in commands))

    def test_documented_tuning_row_matches_each_language_generator(self):
        for language, directory in (("ko", "docs"), ("en", "docs/en")):
            text = (ROOT / directory / "20-optimization.md").read_text()
            blocks = re.findall(r"^```json\n(.*?)^```", text, re.M | re.S)
            with self.subTest(language=language), tempfile.TemporaryDirectory() as temporary:
                self.assertEqual(len(blocks), 1)
                target = Path(temporary) / "tuning"
                result = subprocess.run(
                    [sys.executable, "-c",
                     "import json, sys; from pathlib import Path; sys.path.insert(0, 'samples'); "
                     "import prepare_tuning; print(json.dumps(prepare_tuning.prepare(Path(sys.argv[1]))))",
                     str(target)],
                    cwd=ROOT, env={**os.environ, "FOUNDRY_LAB_LANGUAGE": language, "PYTHONDONTWRITEBYTECODE": "1"},
                    capture_output=True, text=True, timeout=30, check=True,
                )
                train_count, validation_count = json.loads(result.stdout)
                train = [json.loads(line) for line in (target / "train.jsonl").read_text(encoding="utf-8-sig").splitlines()]
                validation = [json.loads(line) for line in (target / "validation.jsonl").read_text(encoding="utf-8-sig").splitlines()]
                self.assertEqual(json.loads(blocks[0]), train[0])
                self.assertEqual((len(train), len(validation)), (train_count, validation_count))
                self.assertIn(f"train={train_count}, validation={validation_count}", text)

    def test_trace_timing_example_uses_intervals_without_double_counting(self):
        for directory in ("docs", "docs/en"):
            text = (ROOT / directory / "10-observability.md").read_text()
            rows = re.findall(r"^\|[^|]+\|\s*([\d,]+)[~–]([\d,]+)\s*\|\s*([\d,]+)ms\s*\|", text, re.M)
            with self.subTest(directory=directory):
                self.assertEqual(len(rows), 4)
                intervals = [tuple(int(value.replace(",", "")) for value in row) for row in rows]
                for start, end, duration in intervals:
                    self.assertEqual(end - start, duration)
                parent = intervals[0][2]
                children = sum(row[2] for row in intervals[1:])
                self.assertIn(f"{children:,}ms", text)
                self.assertIn(f"{parent - children}ms", text)
                self.assertLessEqual(children, parent)
                for previous, following in zip(intervals[1:], intervals[2:]):
                    self.assertLessEqual(previous[1], following[0])

    def test_documented_expense_totals_match_both_synthetic_sources(self):
        for directory, data in (("docs", "data"), ("docs/en", "data/en")):
            with (ROOT / data / "monthly-spend.csv").open() as handle:
                rows = list(csv.DictReader(handle))
            totals = defaultdict(int)
            for row in rows:
                totals[row["month"]] += int(row["amount_krw"])
            for chapter in ("18-multimodal.md", "23-extensions.md"):
                text = (ROOT / directory / chapter).read_text()
                with self.subTest(directory=directory, chapter=chapter):
                    self.assertEqual(len(rows), 9)
                    self.assertEqual(len(totals), 3)
                    for amount in (*totals.values(), sum(totals.values())):
                        self.assertIn(f"{amount:,}", text)

    def test_comments_and_continuations_do_not_inflate_command_count(self):
        text = (
            "```bash\n# comment\nKEY=value python sample.py \\\n"
            "  --flag value\n\npython second.py\n```\n"
            + explanation([
                "| 1. `sample.py` | Set the option. | Local output. |",
                "| 2. `second.py` | Run the second command. | No cloud calls. |",
            ])
        )
        self.assertEqual(command_coverage(text, "fixture"), {"blocks": 1, "commands": 2})

    def test_missing_explanation_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "adjacent command explanation"):
            command_coverage("```bash\npython sample.py\n```\n", "fixture")

    def test_one_row_cannot_explain_two_commands(self):
        text = "```bash\npython a.py\npython b.py\n```\n" + explanation([
            "| 1. both | Run both. | Output. |",
        ])
        with self.assertRaisesRegex(ValueError, "own ordered explanation"):
            command_coverage(text, "fixture")

    def test_duplicate_order_and_empty_explanations_are_rejected(self):
        for rows in (
            ["| 1. a | Run. | Output. |", "| 1. b | Run. | Output. |"],
            ["| 1. a | Run. | Output. |", "| 2. b |  | Output. |"],
        ):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                command_coverage("```bash\npython a.py\npython b.py\n```\n" + explanation(rows), "fixture")

    def test_powershell_command_is_explained(self):
        text = "```powershell\npy -3.13 -m venv .venv\n```\n" + explanation([
            "| 1. `py` | Select Python 3.13. | Create a local environment. |",
        ])
        self.assertEqual(command_coverage(text, "fixture")["commands"], 1)

    def test_dangling_continuation_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "unfinished command"):
            command_coverage("```bash\npython sample.py \\\n```\n", "fixture")


if __name__ == "__main__":
    unittest.main()
