> **완성할 결과:** “노트북 상한 150만 원, 부가세 포함”을 실제 업로드 문서의 근거와 함께 답합니다.

## 목표

모델의 사전 지식 대신 **검색된 문서**로 답하게 합니다. Retrieval-Augmented Generation, 즉 RAG의 가장 짧은 경로입니다.

## 개념과 실습 지도

**경험할 기능:** File search의 파일 업로드·인덱싱·검색·citation입니다.

**무엇이며 왜 중요한가요?** RAG는 질문과 관련된 문서를 먼저 찾고 그 근거로 답하게 하는 방식입니다. 모델을 다시 학습시키는 작업이 아닙니다. Vector store는 검색할 수 있도록 문서를 처리해 보관하는 공간이고, citation은 답변의 근거 위치를 연결하는 정보입니다. 규정이 자주 바뀌는 업무에서는 기억에 의존한 답보다 최신 문서를 확인할 수 있는 답이 중요합니다. 다만 출처 이름을 출력하는 것만으로 실제 검색이 증명되지는 않습니다.

**어떻게 사용하나요?** 원문 세 개를 읽고 정답의 위치를 표시한 뒤 업로드합니다. 인덱싱 완료를 확인하고 단일 문서·교차 문서·없는 정보 질문을 순서대로 보냅니다. 답변 숫자뿐 아니라 클릭한 근거가 실제 문서의 해당 절인지 확인하세요.

**어디서 실행하나요?** 포털에서 File search 연결과 인용을 관찰하고, 선택 SDK로 같은 수명주기를 재현합니다. [구매 정책](../data/policies/procurement-policy.md), [경비 정책](../data/policies/expense-policy.md), [보안 정책](../data/policies/security-policy.md)이 유일한 업무 근거입니다. 구현은 [workshop.py](../samples/workshop.py)에 있습니다.

## 준비

L04의 agent와 `data/policies/`의 Markdown 파일 3개를 사용합니다. 저장소 업로드 권한과 File search 추가 비용을 확인하세요. 회사 문서를 가져오지 않아도 실습할 수 있습니다.

## 실행

### 1. 세 문서를 먼저 읽기

| 파일 | 들어 있는 정보 | 들어 있지 않은 정보 |
| --- | --- | --- |
| `procurement-policy.md` | 품목별 상한, 36개월 교체, 승인 경계 | 현재 재고 |
| `expense-policy.md` | 사전 승인, 증빙, 환율 확인, 중복 금지 | 오늘 환율 |
| `security-policy.md` | 권한·데이터·실행 경계 | 개인별 인사 데이터 |

정답의 위치를 모르면 RAG 품질을 평가할 수 없습니다.

### 2. File search 연결하기

Agent builder의 **Tools/Knowledge**에서 **File search**를 추가합니다. UI가 Toolbox 연결을 제시하면 file-search 도구를 담은 Toolbox를 연결합니다. 직접 도구 연결도 지원되지만 재사용·운영 패턴은 Toolbox가 권장됩니다.

새 vector store를 만들고 파일 3개를 업로드합니다. 인덱싱이 **Completed**인지 확인한 후 질문합니다. 업로드가 끝났다는 것과 검색 준비가 끝났다는 것은 다릅니다.

![실제 agent의 Instructions를 접어 Tools와 Knowledge를 펼쳐 볼 수 있게 한 화면. File search 카드와 별도의 get_stock·prepare_purchase_request 함수가 구분되어 있다.](../assets/portal/05-agent-tools.png)

**화면 따라 읽기:** **Tools**의 **File search** 카드에서 연결된 store와 검색 설정을 확인합니다. 식별자는 화면에서 가렸으므로 자신의 store 값을 사용하세요. 그 아래 `get_stock`·`prepare_purchase_request`는 L06에서 설명할 함수이며 파일 검색 자체의 기능이 아닙니다. 사진에 도구가 나열돼 있다는 것만으로 인덱싱 완료·citation 정확도를 판정하지 말고, 아래 질문의 실제 근거를 확인합니다.

### 3. 정답·교차 문서·모름을 차례로 실험하기

```text
노트북 가격 상한과 정기 교체 주기를 알려줘. 문서명과 절을 제시해줘.
```

기대: **150만 원, 부가세 포함, 36개월, procurement-policy.md 2절**.

```text
노트북 2대를 총액 290만 원에 사려 합니다.
누구의 승인이 필요하고, 사전 승인 없이 구매하면 비용 처리할 수 있나요?
```

기대: **팀장 + 구매 담당자** 승인과, 사전 승인 없는 구매의 **원칙적 비용 처리 불가/서면 예외 검토**. 두 문서 근거를 구분합니다.

```text
독일 지사의 구매 규정도 알려줘.
```

기대: 제공 문서에서 확인할 수 없다고 답합니다. 출처를 만들어내면 실패입니다.

### 4. citation을 실제로 열어보기

대답에 파일 이름이 적혀 있는 것만으로 성공이 아닙니다. portal의 인용이나 SDK의 `annotations`가 **실제 업로드 파일/검색 결과**를 가리키는지 확인합니다. 근거에 없는 숫자를 섞지 않았는지도 점검합니다.

SDK 경로:

```bash
python samples/workshop.py rag
python samples/workshop.py rag --live
```

<div class="command-explanation" markdown="1">

**명령 해설**

| 순서·명령 | 세부 동작과 옵션 | 결과·비용/변경 |
| --- | --- | --- |
| 1. `rag` | 사용할 합성 정책과 RAG 실행 계획을 표시합니다. `--live`가 없어 업로드하지 않습니다. | 로컬 계획 확인만 수행합니다. |
| 2. `rag --live` | 파일 업로드 → vector store 연결 → 최대 180초 인덱싱 대기 → 새 agent 생성 → 질문을 실제 수행합니다. | 모델·File search·파일 보관 비용 가능. 답변의 citation과 receipt의 파일/store ID를 대조합니다. 포털 객체를 재사용하는 명령은 아닙니다. |

</div>

실행 파일은 업로드 → vector store 파일 연결 → 최대 180초 인덱싱 대기 → agent 생성 → 질문을 진행합니다. 180초 안에 끝나지 않으면 완료로 가장하지 않고 중단합니다. receipt로 남은 파일과 상태를 확인하세요.

### 5. 검색 실패를 분해하기

![질문, 검색, 근거, 답변, 평가, 개선으로 이어지는 학습 루프](../assets/learning-loop.svg)

| 현상 | 먼저 볼 계층 |
| --- | --- |
| 관련 문서가 검색되지 않음 | 인덱싱·chunk·검색 설정 |
| 문서는 맞는데 답이 틀림 | instructions·질문·모델 |
| 답은 맞지만 출처가 없음 | citation 처리·화면 렌더링 |
| 다른 사용자의 자료가 보임 | 데이터 권한·검색 필터·호출자 ID |

## 성공 기준

정답 질문 2개에 실제 근거가 있고, 문서에 없는 질문은 유보합니다. 응답의 사실을 원문과 대조했으며 인덱싱 완료 상태를 확인했습니다.

## 막혔을 때

“문서를 다시 올려보자”부터 시작하지 않습니다. 연결한 vector store ID, 인덱싱 실패 사유, 지원 파일 형식, 모델/tool 지원, 올바른 agent 버전을 확인합니다. 실제 파일에 이미지로만 들어 있는 표라면 File search만으로 충분한지 L18에서 검토합니다.

## 정리

다음 실습을 위해 포털 지식 연결을 유지합니다. SDK 샘플의 vector store는 **마지막 활동 후 1일** 만료를 설정하지만 업로드 파일은 별도입니다. 만료에만 의존하지 말고 L12에서 삭제합니다.

<details markdown="1">
<summary>File search와 Foundry IQ는 언제 나누나요?</summary>

파일 몇 개로 빠르게 검증하려면 File search. 직접 인덱스·hybrid 검색·필터를 제어하려면 Azure AI Search. 여러 지식 소스와 agentic retrieval을 공유하려면 Foundry IQ를 검토합니다. 어느 경로도 연결만으로 사용자별 문서 권한이 자동 완성되지는 않습니다.

</details>
